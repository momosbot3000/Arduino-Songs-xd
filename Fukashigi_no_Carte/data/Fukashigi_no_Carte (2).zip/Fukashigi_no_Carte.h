#ifndef Fukashigi_no_Carte_h
#define Fukashigi_no_Carte_h

#include "Arduino.h"

class Fukashigi_no_Carte_h 
{
  private: 
    int buzzer;
  public:
    void PlaySong(buzzer);
};

#endif